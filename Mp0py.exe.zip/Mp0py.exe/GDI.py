import ctypes
import sys
import random
import time
import threading

def mostrar_msgbox(titulo, mensagem):
    resposta = ctypes.windll.user32.MessageBoxW(
        0,
        mensagem,
        titulo,
        0x04 | 0x30
    )
    return resposta

if mostrar_msgbox(
    "Aviso de Epilepsia",
    "Esse Malware pode fazer desmaiar.\nSe você é epiléptico, clique em NÃO."
) == 7:
    sys.exit()

if mostrar_msgbox(
    "Ultimo aviso",
    "Esse Malware pode fazer desmaiar.\nSe você é epiléptico, clique em NÃO."
) == 7:
    sys.exit()

hdc = ctypes.windll.user32.GetDC(0)

def desenhar_texto(texto):
    x = random.randint(0, ctypes.windll.user32.GetSystemMetrics(0) - 200)
    y = random.randint(0, ctypes.windll.user32.GetSystemMetrics(1) - 50)
    cor = random.randint(0, 0xFFFFFF)
    ctypes.windll.gdi32.SetTextColor(hdc, cor)
    ctypes.windll.gdi32.SetBkMode(hdc, 1)
    ctypes.windll.gdi32.TextOutW(hdc, x, y, texto, len(texto))

def tocar_zi_poo():
    while True:
        ctypes.windll.kernel32.Beep(4000, 800)  # Ziiiiii (4 kHz)
        ctypes.windll.kernel32.Beep(200, 800)   # Poooo (200 Hz grave)

threading.Thread(target=tocar_zi_poo, daemon=True).start()

mensagens = ["Mp0py.exe ✨", "Mp0py.exe está no controle!"]

try:
    while True:
        desenhar_texto(random.choice(mensagens))
        time.sleep(0.05)
except KeyboardInterrupt:
    pass

